A Pen created at CodePen.io. You can find this one at http://codepen.io/jfulgar/pen/gkKAH.

 A simple, yet subtle pen to randomize number values, connected to the RGB CSS property, creating random background colors when you click the half circle.

too dope!

Credit to: Mark Reale for help on the generator