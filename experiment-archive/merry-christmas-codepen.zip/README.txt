A Pen created at CodePen.io. You can find this one at http://codepen.io/lcdvirgo/pen/Kwgagd.

 A little greeting from here at Green Chameleon Design to all you at Codepen. Can also be customised at http://craftedbygc.com/merryxmas-codepen by changing the url to "craftedbygc.com/merryxmas-{whatever-you-like}"

Based on the "It's snowing" pen (http://codepen.io/loktar00/pen/CHpGo) by Jason (http://codepen.io/loktar00/)

Forked from [Green Chameleon](http://codepen.io/craftedbygc/)'s Pen [Merry Christmas, Codepen!](http://codepen.io/craftedbygc/pen/yyJamr/).